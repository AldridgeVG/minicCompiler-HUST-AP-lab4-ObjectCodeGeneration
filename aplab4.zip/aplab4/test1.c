int cjt1,cjt2;
float cjt3;
int test(int a)
{
  char cjt4[25];
  int a2=1;
  int a1=2;
  a1=a1/a2;
  if(a1==1)
  {
    a2=3;
  }
  else
  {
    int j;
    j=cjt2;
  }
  return 0;
}
int main()
{
  int a1,a2=1;
  test(3);
  test(a2);
  while(a2>0){
    if(a1==3) continue;
    break;
  }
  return 1;
}