运行环境：
Windows 10 专业版

win_flex 2.6.4
win_bison 2.7

（注：c.bat可调整为flex/bison命令。win_flex_bison下载安装网址：https://sourceforge.net/projects/winflexbison/

gcc 9.2
QtSpim 9.1.21

命令已编写为脚本c.bat，执行bat运行即可
（注：但是脚本在vscode的终端运行可能因为非等宽字体引起格式问题，建议终端直接运行这c.bat的四条语句，运行前使用命令chcp 65001切换编码至UTF-8

注：未完成多维数组，结构体，for循环